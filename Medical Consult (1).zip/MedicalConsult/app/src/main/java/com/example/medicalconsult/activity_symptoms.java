package com.example.medicalconsult;

import androidx.appcompat.app.AppCompatActivity;
import android.content.Intent;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.Spinner;
import android.widget.Toast;
import java.util.ArrayList;

public class activity_symptoms extends AppCompatActivity {

    Button dis;
    Spinner s1,s2,s3,s4,s5,s6,s7;
    String d[] = new String[7];

    DatabaseHelper dbHelper;
    SQLiteDatabase db;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_symptoms);
        dis= findViewById(R.id.disease);
        s1 = findViewById(R.id.syp1);
        s2 = findViewById(R.id.syp2);
        s3 = findViewById(R.id.syp3);
        s4 = findViewById(R.id.syp4);
        s5 = findViewById(R.id.syp5);
        s6 = findViewById(R.id.syp6);
        s7 = findViewById(R.id.syp7);
        final String name = getIntent().getStringExtra("name");
        final String gender = getIntent().getStringExtra("gender");

        dbHelper = new DatabaseHelper(this);
        db = dbHelper.getReadableDatabase();

        ArrayList<String> diarrhoea = getSymptoms("Diarrhoea");
        ArrayList<String> malaria = getSymptoms("Malaria");
        ArrayList<String> typhoid = getSymptoms("Typhoid");
        ArrayList<String> diabetes = getSymptoms("Diabetes");
        ArrayList<String> blood_pressure = getSymptoms("Blood Pressure");
        ArrayList<String> cardio_disease = getSymptoms("Cardio Disease");

        dis.setOnClickListener(v-> {
            int symptomCount = 0;
            if (!s1.getSelectedItem().toString().equals("SELECT SYMPTOM")) symptomCount++;
            if (!s2.getSelectedItem().toString().equals("SELECT SYMPTOM")) symptomCount++;
            if (!s3.getSelectedItem().toString().equals("SELECT SYMPTOM")) symptomCount++;
            if (!s4.getSelectedItem().toString().equals("SELECT SYMPTOM")) symptomCount++;
            if (!s5.getSelectedItem().toString().equals("SELECT SYMPTOM")) symptomCount++;
            if (!s6.getSelectedItem().toString().equals("SELECT SYMPTOM")) symptomCount++;
            if (!s7.getSelectedItem().toString().equals("SELECT SYMPTOM")) symptomCount++;

            if(symptomCount < 2) {
                Toast.makeText(this, "Please select at least two symptoms", Toast.LENGTH_SHORT).show();
                return;
            }

            int c[] = new int[6];
            d[0] = s1.getSelectedItem().toString();
            d[1] = s2.getSelectedItem().toString();
            d[2] = s3.getSelectedItem().toString();
            d[3] = s4.getSelectedItem().toString();
            d[4] = s5.getSelectedItem().toString();
            d[5] = s6.getSelectedItem().toString();
            d[6] = s7.getSelectedItem().toString();

            for( int i = 0 ; i < 7 ; i++)
            {
                for( int j=1 ; j <= 6; j++)
                {
                    switch (j)
                    {
                        case 1 : {
                            int l = 0;
                            l = diarrhoea.size();
                            for(int k=0 ; k<l ; k++ )
                            {
                                if(d[i].equals(diarrhoea.get(k)) )
                                {
                                    c[0]++;
                                }
                            }
                            break; }

                        case 2: {
                            int l = 0;
                            l = malaria.size();
                            for (int k = 0; k < l; k++) {
                                if (d[i].equals(malaria.get(k))) {
                                    c[1]++;
                                }
                            }
                            break;
                        }

                        case 3: {
                            int l = 0;
                            l = typhoid.size();
                            for (int k = 0; k < l; k++) {
                                if (d[i].equals(typhoid.get(k))) {
                                    c[2]++;
                                }
                            }
                            break;
                        }

                        case 4: {
                            int l = 0;
                            l = diabetes.size();
                            for (int k = 0; k < l; k++) {
                                if (d[i].equals(diabetes.get(k))) {
                                    c[3]++;
                                }
                            }
                            break;
                        }

                        case 5: {
                            int l = 0;
                            l = blood_pressure.size();
                            for (int k = 0; k < l; k++) {
                                if (d[i].equals(blood_pressure.get(k))) {
                                    c[4]++;
                                }
                            }
                            break;
                        }

                        case 6: {
                            int l = 0;
                            l = cardio_disease.size();
                            for (int k = 0; k < l; k++) {
                                if (d[i].equals(cardio_disease.get(k))) {
                                    c[5]++;
                                }
                            }
                            break;
                        }
                    }
                }
            }

            int max = c[0];
            for( int m=0; m<6 ; m++)
            {
                if(c[m] > max)
                    max = c[m];
            }
    
            Intent dis_page = new Intent(activity_symptoms.this,activity_disease.class);
            dis_page.putExtra("name",name);
            dis_page.putExtra("gender",gender);
            dis_page.putExtra("max",max);
            dis_page.putExtra("c",c);
            startActivity(dis_page);
        });
    }

    public ArrayList<String> getSymptoms(String disease) {
        String[] projection = {
            "symptom"
        };

        String selection = "disease_name = ?";
        String[] selectionArgs = { disease };

        Cursor cursor = db.query(
            "diseases",
            projection,
            selection,
            selectionArgs,
            null,
            null,
            null
        );

        ArrayList<String> symptoms = new ArrayList<>();
        while(cursor.moveToNext()) {
            String symptom = cursor.getString(cursor.getColumnIndexOrThrow("symptom"));
            symptoms.add(symptom);
        }
        cursor.close();

        return symptoms;
    }
}