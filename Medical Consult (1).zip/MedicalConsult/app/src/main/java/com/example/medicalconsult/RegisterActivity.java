package com.example.medicalconsult;

import android.content.Intent;
import android.os.Bundle;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;

import com.google.firebase.auth.FirebaseAuth;

public class RegisterActivity extends AppCompatActivity {
    EditText emailedittext, passwordedittext, confirmpasswordedittext;
    Button register_button;
    TextView login_button;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.activity_register);

        emailedittext = findViewById(R.id.email);
        passwordedittext = findViewById(R.id.password);
        confirmpasswordedittext = findViewById(R.id.confirm_password);
        register_button = findViewById(R.id.register);
        login_button = findViewById(R.id.login);


        login_button.setOnClickListener(v -> {
            startActivity(new Intent(RegisterActivity.this, Login.class));
        });
        register_button.setOnClickListener(v -> validateRegister());
    }

    private void validateRegister() {
        String email = emailedittext.getText().toString();
        String password = passwordedittext.getText().toString();
        String confirmpassword = confirmpasswordedittext.getText().toString();
        if (email.isEmpty()) {
            emailedittext.setError("Email is required");
            emailedittext.requestFocus();
            return;
        }else if(!email.matches("[a-zA-Z0-9._-]+@[a-z]+\\.+[a-z]+")){
            emailedittext.setError("Invalid Email Address");
            emailedittext.requestFocus();
            return;
        }
        else if (password.isEmpty()) {
            passwordedittext.setError("Password is required");
            passwordedittext.requestFocus();
            return;
        }
        else if (password.length() < 6) {
            passwordedittext.setError("Password should be atleast 6 characters long");
            passwordedittext.requestFocus();
            return;
        }
        else if (confirmpassword.isEmpty()) {
            confirmpasswordedittext.setError("Confirm Password is required");
            confirmpasswordedittext.requestFocus();
            return;
        }
        else if (!password.equals(confirmpassword)) {
            confirmpasswordedittext.setError("Passwords do not match");
            confirmpasswordedittext.requestFocus();
            return;
        }
        else {
            FirebaseAuth.getInstance().createUserWithEmailAndPassword(email, password)
                    .addOnCompleteListener(task -> {
                        if (task.isSuccessful()) {
                            startActivity(new Intent(RegisterActivity.this, MainActivity.class));
                            Toast.makeText(this, "Registered With Success", Toast.LENGTH_SHORT).show();
                        } else {
                            Toast.makeText(RegisterActivity.this, "Registration failed", Toast.LENGTH_SHORT).show();
                        }
                    });
        }
    }
}