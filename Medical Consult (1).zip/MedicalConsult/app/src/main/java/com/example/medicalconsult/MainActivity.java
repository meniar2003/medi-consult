package com.example.medicalconsult;

import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.RadioButton;
import android.widget.RadioGroup;
import android.widget.Toast;

import androidx.appcompat.widget.Toolbar;

import androidx.appcompat.app.ActionBarDrawerToggle;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.view.GravityCompat;
import androidx.drawerlayout.widget.DrawerLayout ;

import com.google.android.material.navigation.NavigationView;

public class MainActivity extends AppCompatActivity {
    Toolbar t;
    DrawerLayout drawer;
    EditText nametext;
    EditText agetext;
    ImageView enter;
    RadioButton male;
    RadioButton female;
    RadioGroup rg;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        initView();
        initEvent();
    }


    public void initView(){
        drawer = findViewById(R.id.draw_activity);
        t = (Toolbar) findViewById(R.id.toolbar);
        nametext = findViewById(R.id.nametext);
        agetext = findViewById(R.id.agetext);
        enter = findViewById(R.id.imageView7);
        male = findViewById(R.id.male);
        female = findViewById(R.id.female);
        rg=findViewById(R.id.rg1);
    }


    public void initEvent(){
        ActionBarDrawerToggle toggle = new ActionBarDrawerToggle(this, drawer, t, R.string.navigation_drawer_open, R.string.navigation_drawer_close);
        drawer.addDrawerListener(toggle);
        toggle.syncState();
        NavigationView nav = findViewById(R.id.nav_view);
        enter.setOnClickListener(v-> {
                String name = nametext.getText().toString();
                String gender= "";
                int id=rg.getCheckedRadioButtonId();
                if (id == R.id.male) {
                    gender = "Mr.";
                } else if (id == R.id.female) {
                    gender = "Ms.";
                }
                if(name.equals("")){
                    nametext.setError("Name is required");
                    nametext.requestFocus();
                    return;
                }else if(name.length()<3){
                    nametext.setError("Name is too short");
                    nametext.requestFocus();
                    return;
                }
                else if(name.length()>20){
                    nametext.setError("Name is too long");
                    nametext.requestFocus();
                    return;
                }
                else if(!name.matches("[a-zA-Z ]+")){
                    nametext.setError("Name is too short");
                    nametext.requestFocus();
                    return;
                }
                else if(agetext.getText().toString().equals("")){
                    agetext.setError("Age is required");
                    agetext.requestFocus();
                    return;
                }else if(Integer.parseInt(agetext.getText().toString())>100){
                    agetext.setError("Invalid age");
                    agetext.requestFocus();
                    return;
                }else if(Integer.parseInt(agetext.getText().toString())<1){
                    agetext.setError("Invalid age");
                    agetext.requestFocus();
                    return;
                }
                else if(rg.getCheckedRadioButtonId() == -1){
                    Toast.makeText(MainActivity.this, "Please select your gender", Toast.LENGTH_SHORT).show();
                    return;
                }
                Intent symp = new Intent(MainActivity.this,activity_symptoms.class);
                symp.putExtra("name",name);
                symp.putExtra("gender",gender);
                startActivity(symp);

            });
        nav.setNavigationItemSelectedListener(v->{
            int itemId = v.getItemId();
            if (itemId == R.id.login) {
                startActivity(new Intent(MainActivity.this, Login.class));
            }
            drawer.closeDrawer(GravityCompat.START);
            return true;
                });
    }
}
