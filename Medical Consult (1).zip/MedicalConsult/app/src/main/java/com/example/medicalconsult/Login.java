package com.example.medicalconsult;

import android.content.Intent;
import android.os.Bundle;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;

import com.google.firebase.auth.FirebaseAuth;

public class Login extends AppCompatActivity {
    EditText emailedittext, passwordedittext;
    Button login_button;
    TextView register_button;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.activity_login);

        emailedittext = findViewById(R.id.email);
        passwordedittext = findViewById(R.id.password);
        login_button = findViewById(R.id.login);
        register_button = findViewById(R.id.register);

        register_button.setOnClickListener(v -> {
            startActivity(new Intent(Login.this, RegisterActivity.class));
        });
        login_button.setOnClickListener(v -> validateLogin());
    }

    private void validateLogin() {
        String email = emailedittext.getText().toString();
        String password = passwordedittext.getText().toString();
        if (email.isEmpty()) {
            emailedittext.setError("Email is required");
            emailedittext.requestFocus();
            return;
        }else if(!email.matches("[a-zA-Z0-9._-]+@[a-z]+\\.+[a-z]+")){
            emailedittext.setError("Invalid Email Address");
            emailedittext.requestFocus();
            return;
        }
        else if (password.isEmpty()) {
            passwordedittext.setError("Password is required");
            passwordedittext.requestFocus();
            return;
        }
        else if (password.length() < 6) {
            passwordedittext.setError("Password should be atleast 6 characters long");
            passwordedittext.requestFocus();
            return;
        }
        else {
            FirebaseAuth.getInstance().signInWithEmailAndPassword(email, password)
                    .addOnCompleteListener(task -> {
                        if (task.isSuccessful()) {
                            startActivity(new Intent(Login.this, MainActivity.class));
                            Toast.makeText(Login.this, "Login Successful", Toast.LENGTH_SHORT).show();
                        } else {
                            Toast.makeText(Login.this, "Login Failed", Toast.LENGTH_SHORT).show();
                        }
                    });
        }}

}