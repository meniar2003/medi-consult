package com.example.medicalconsult;

import android.content.ContentValues;
import android.content.Context;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;

public class DatabaseHelper extends SQLiteOpenHelper {

    private static final String DATABASE_NAME = "MedicalConsult.db";
    private static final int DATABASE_VERSION = 1;

    public DatabaseHelper(Context context) {
        super(context, DATABASE_NAME, null, DATABASE_VERSION);
    }

    @Override
    public void onCreate(SQLiteDatabase db) {
        String CREATE_TABLE = "CREATE TABLE diseases (id INTEGER PRIMARY KEY, disease_name TEXT, symptom TEXT)";
        db.execSQL(CREATE_TABLE);
    }

    @Override
    public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {
        db.execSQL("DROP TABLE IF EXISTS diseases");
        onCreate(db);
    }

    public void insertDisease(String disease, String[] symptoms) {
        SQLiteDatabase db = this.getWritableDatabase();
        for (String symptom : symptoms) {
            ContentValues values = new ContentValues();
            values.put("disease_name", disease);
            values.put("symptom", symptom);
            db.insert("diseases", null, values);
        }
    }

    public void insertInitialData() {
        // Insert diseases and their symptoms
        insertDisease("Diarrhoea", new String[]{"Stomach Ache","Nausea","Vomiting","Fever","Sudden Weight Loss"});
        insertDisease("Malaria", new String[]{"Fever","Vomiting","Sweating","Muscle And Body Pain","Headaches"});
        insertDisease("Typhoid", new String[]{"Fever","Headaches","Weakness/Fatigue","Abdominal Pain","Muscle Pain","Dry Cough","Diarrhoea/Constipation"});
        insertDisease("Diabetes", new String[]{"Frequent Urination","Hunger","Thirsty Than Usual","Sudden Weight Loss","Blurred Vision","Skin Itching"});
        insertDisease("Blood Pressure", new String[]{"Headaches","Blurred Vision","Chest Pain","Shortness in Breath","Dizziness","Nausea","Vomiting"});
        insertDisease("Cardio Disease", new String[]{"Shortness in Breath","Fast Heartbeat","Indigestion","Pressure Or Heaviness In Chest","Anxiety"});
    }
}